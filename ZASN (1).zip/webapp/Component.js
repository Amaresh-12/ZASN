sap.ui.define(["sap/ui/generic/app/AppComponent"], function (AppComponent) {
	return AppComponent.extend("ZASN.ZASN.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});